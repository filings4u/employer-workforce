# screenings4u Workforce Employer

Domain: https://employer-workforce.screenings4u.com

Portal code: `employer_workforce`

Backend: Workforce Supabase project `wyezpseboxbmkedvbmyx`.

Authentication uses Supabase Auth and the portal's dedicated NON-DOT Workforce Edge Function session context.

Paid management portal. Essential, Professional, and Enterprise subscriptions are selected by subscription ID when a user has access to more than one plan.
